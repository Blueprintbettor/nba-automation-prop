"""
Slip Builder - Formats Discord messages for NBA props
"""
from datetime import datetime


def build_discord_slip(evaluated_props):
    """
    Build a professional Discord slip with emojis and formatting
    
    Args:
        evaluated_props: List of props with evaluation results
    
    Returns:
        Formatted Discord message string
    """
    today = datetime.now().strftime("%A, %B %d, %Y")
    
    # Header
    lines = [
        "```",
        "═══════════════════════════════════════",
        "    🏀 NBA PROPS ANALYZER 🏀",
        f"    {today}",
        "═══════════════════════════════════════",
        "```",
        ""
    ]
    
    # Filter props by recommendation category
    plays = [p for p in evaluated_props if '✅ PLAY' in p.get('evaluation', {}).get('recommendation', '')]
    leans = [p for p in evaluated_props if '⚠️ LEAN' in p.get('evaluation', {}).get('recommendation', '')]
    avoids = [p for p in evaluated_props if '❌ AVOID' in p.get('evaluation', {}).get('recommendation', '')]
    
    # Strong Plays Section
    if plays:
        lines.append("**📊 STRONG PLAYS**")
        lines.append("```")
        for i, prop in enumerate(plays, 1):
            lines.extend(_format_prop_entry(i, prop))
        lines.append("```")
        lines.append("")
    
    # Lean Plays Section
    if leans:
        lines.append("**⚠️ LEAN PLAYS**")
        lines.append("```")
        for i, prop in enumerate(leans, 1):
            lines.extend(_format_prop_entry(i, prop))
        lines.append("```")
        lines.append("")
    
    # Avoid Section (optional, can be commented out)
    if avoids and len(avoids) <= 3:  # Only show if few avoids
        lines.append("**❌ AVOID**")
        lines.append("```")
        for i, prop in enumerate(avoids, 1):
            lines.extend(_format_prop_entry(i, prop, brief=True))
        lines.append("```")
        lines.append("")
    
    # Summary
    lines.append("**📈 SUMMARY**")
    lines.append("```")
    lines.append(f"Total Props:    {len(evaluated_props)}")
    lines.append(f"Strong Plays:   {len(plays)}")
    lines.append(f"Leans:          {len(leans)}")
    lines.append(f"Avoid:          {len(avoids)}")
    lines.append("```")
    
    # Footer
    lines.append("")
    lines.append("_Powered by Blueprint Bettor | Data from BallDontLie API_")
    
    return "\n".join(lines)


def _format_prop_entry(index, prop, brief=False):
    """
    Format a single prop entry
    
    Args:
        index: Entry number
        prop: Prop dict with player, stat, line, avg_pra, evaluation
        brief: If True, show abbreviated format
    
    Returns:
        List of formatted lines
    """
    player = prop.get('player', 'Unknown')
    stat = prop.get('stat', 'PRA')
    line = prop.get('line', 'N/A')
    avg_pra = prop.get('avg_pra', 'N/A')
    eval_data = prop.get('evaluation', {})
    edge = eval_data.get('edge', 0)
    confidence = eval_data.get('confidence', 'N/A')
    
    lines = []
    
    if brief:
        # Brief format for avoids
        lines.append(f"{index}. {player} - {stat} {line}")
        lines.append(f"   L5 Avg: {avg_pra} | Edge: {edge:+.1f}")
    else:
        # Full format
        lines.append(f"{index}. {player}")
        lines.append(f"   Prop:       {stat} {line}")
        lines.append(f"   L5 Avg PRA: {avg_pra}")
        lines.append(f"   Edge:       {edge:+.1f}")
        lines.append(f"   Confidence: {confidence}")
    
    lines.append("")
    return lines


def build_simple_slip(evaluated_props):
    """
    Build a simple, compact Discord message (alternative format)
    
    Args:
        evaluated_props: List of props with evaluation results
    
    Returns:
        Formatted Discord message string
    """
    today = datetime.now().strftime("%B %d, %Y")
    
    lines = [
        f"**🏀 NBA Props - {today}**",
        ""
    ]
    
    # Filter strong plays
    plays = [p for p in evaluated_props if '✅ PLAY' in p.get('evaluation', {}).get('recommendation', '')]
    
    if not plays:
        lines.append("_No strong plays identified for today._")
        return "\n".join(lines)
    
    for i, prop in enumerate(plays, 1):
        player = prop.get('player', 'Unknown')
        stat = prop.get('stat', 'PRA')
        line = prop.get('line', 'N/A')
        avg_pra = prop.get('avg_pra', 'N/A')
        edge = prop.get('evaluation', {}).get('edge', 0)
        
        lines.append(f"**{i}. {player}** - {stat} {line}")
        lines.append(f"   L5 Avg: {avg_pra} | Edge: {edge:+.1f} ✅")
        lines.append("")
    
    lines.append(f"_Total plays: {len(plays)}_")
    
    return "\n".join(lines)
