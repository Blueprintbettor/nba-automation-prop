import os
import requests
from flask import Flask, jsonify
from google.auth import default
from googleapiclient.discovery import build
from datetime import datetime
from bdl_api import get_last_5_avg_pra
from pra_evaluator import evaluate_all_props, get_plays_summary
from slip_builder import build_discord_slip, build_simple_slip

app = Flask(__name__)

DISCORD_WEBHOOK = os.environ.get("DISCORD_WEBHOOK_URL")
SHEET_ID = os.environ.get("SHEET_ID")
SHEET_RANGE = os.environ.get("SHEET_RANGE", "INPUT_LINES!A2:E50")
USE_SIMPLE_FORMAT = os.environ.get("USE_SIMPLE_FORMAT", "false").lower() == "true"

def get_sheets_service():
    """Get authenticated Google Sheets service"""
    credentials, _ = default(scopes=['https://www.googleapis.com/auth/spreadsheets.readonly'])
    return build('sheets', 'v4', credentials=credentials)

def read_sheet_data():
    """Read prop data from Google Sheets"""
    service = get_sheets_service()
    result = service.spreadsheets().values().get(spreadsheetId=SHEET_ID, range=SHEET_RANGE).execute()
    values = result.get('values', [])
    props = []
    for row in values:
        if len(row) < 2:
            continue
        prop = {
            'date': row[0] if len(row) > 0 else '',
            'player': row[1] if len(row) > 1 else '',
            'stat': row[2] if len(row) > 2 else '',
            'line': row[3] if len(row) > 3 else '',
            'notes': row[4] if len(row) > 4 else ''
        }
        props.append(prop)
    return props

def fetch_pra_stats(props):
    """Fetch PRA averages for all props"""
    for prop in props:
        print(f"Fetching stats for {prop['player']}...")
        avg_pra = get_last_5_avg_pra(prop['player'])
        prop['avg_pra'] = avg_pra if avg_pra is not None else 'N/A'
    return props

def format_discord_message(evaluated_props):
    """Format Discord message based on configuration"""
    if not evaluated_props:
        return "🏀 NBA Props - No plays found for today."
    
    if USE_SIMPLE_FORMAT:
        return build_simple_slip(evaluated_props)
    else:
        return build_discord_slip(evaluated_props)

def post_to_discord(message):
    """Post message to Discord webhook with retry logic"""
    if not DISCORD_WEBHOOK:
        print("No Discord webhook configured")
        return False
    
    for attempt in range(3):
        try:
            resp = requests.post(DISCORD_WEBHOOK, json={"content": message}, timeout=10)
            if resp.status_code in [200, 204]:
                print(f"Successfully posted to Discord (attempt {attempt + 1})")
                return True
            else:
                print(f"Discord returned status {resp.status_code}")
        except Exception as e:
            print(f"Discord post error (attempt {attempt + 1}): {e}")
    
    return False

@app.route("/")
def health():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "service": "NBA Props Analyzer"}), 200

@app.route("/run", methods=["POST", "GET"])
def run_nba_props():
    """Main endpoint to process NBA props"""
    if not DISCORD_WEBHOOK or not SHEET_ID:
        return jsonify({"ok": False, "error": "Missing DISCORD_WEBHOOK_URL or SHEET_ID config"}), 500
    
    try:
        print("Starting NBA props analysis...")
        
        # Step 1: Read props from Google Sheets
        print("Reading data from Google Sheets...")
        props = read_sheet_data()
        print(f"Found {len(props)} props")
        
        if not props:
            message = "🏀 NBA Props - No props found in sheet"
            post_to_discord(message)
            return jsonify({"ok": True, "props_count": 0, "message": "No props found"}), 200
        
        # Step 2: Fetch PRA stats from BallDontLie API
        print("Fetching PRA stats from BallDontLie...")
        props_with_stats = fetch_pra_stats(props)
        
        # Step 3: Evaluate all props
        print("Evaluating props...")
        evaluated_props = evaluate_all_props(props_with_stats)
        
        # Step 4: Get summary
        summary = get_plays_summary(evaluated_props)
        print(f"Summary: {summary}")
        
        # Step 5: Format Discord message
        print("Formatting Discord message...")
        message = format_discord_message(evaluated_props)
        
        # Step 6: Post to Discord
        print("Posting to Discord...")
        success = post_to_discord(message)
        
        if success:
            print("Successfully posted to Discord!")
            return jsonify({
                "ok": True,
                "props_count": len(props),
                "summary": summary,
                "message": "Successfully posted to Discord"
            }), 200
        else:
            print("Failed to post to Discord")
            return jsonify({
                "ok": False,
                "error": "Failed to post to Discord after retries"
            }), 500
            
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)}), 500

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    print(f"Starting NBA Props Analyzer on port {port}...")
    app.run(host="0.0.0.0", port=port, debug=False)
