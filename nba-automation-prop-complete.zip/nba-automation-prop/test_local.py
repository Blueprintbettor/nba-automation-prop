#!/usr/bin/env python3
"""
Local test script for NBA Props Analyzer
Run this to test locally before deploying
"""

import os
from main import read_sheet_data, fetch_pra_stats, evaluate_all_props, format_discord_message

# Set environment variables for testing
os.environ['SHEET_ID'] = '1BEWBO-JZWQIjAtIgL69sK47ZXnLPwkE4VYI_uVVq8bg'
os.environ['SHEET_RANGE'] = 'INPUT_LINES!A2:E50'
os.environ['DISCORD_WEBHOOK_URL'] = 'https://discord.com/api/webhooks/1456668428784894184/QQeq0pHtiZWZqHpiQ2pyRxIf3CyZ64sqAohB0RW_yu_9oiWg1fEntfrlz88fV13_JXkp'

def test_analysis():
    """Test the complete analysis workflow"""
    print("=" * 50)
    print("NBA Props Analyzer - Local Test")
    print("=" * 50)
    
    try:
        # Step 1: Read from Sheets
        print("\n1. Reading from Google Sheets...")
        props = read_sheet_data()
        print(f"   ✓ Found {len(props)} props")
        
        if not props:
            print("   ⚠ No props found in sheet")
            return
        
        # Display props
        for i, prop in enumerate(props, 1):
            print(f"   {i}. {prop['player']} - {prop['stat']} {prop['line']}")
        
        # Step 2: Fetch stats
        print("\n2. Fetching PRA stats from BallDontLie...")
        props_with_stats = fetch_pra_stats(props)
        print(f"   ✓ Fetched stats for {len(props_with_stats)} players")
        
        # Step 3: Evaluate
        print("\n3. Evaluating props...")
        evaluated = evaluate_all_props(props_with_stats)
        
        for prop in evaluated:
            rec = prop['evaluation']['recommendation']
            print(f"   {prop['player']}: {rec}")
        
        # Step 4: Format message
        print("\n4. Formatting Discord message...")
        message = format_discord_message(evaluated)
        
        print("\n" + "=" * 50)
        print("DISCORD MESSAGE PREVIEW:")
        print("=" * 50)
        print(message)
        print("=" * 50)
        
        print("\n✓ Test completed successfully!")
        print("\nTo post to Discord, run:")
        print("  curl -X POST http://localhost:8080/run")
        
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_analysis()
