"""
PRA Evaluator - Determines if props hit or miss based on player averages
"""

def evaluate_pra_prop(line, avg_pra, over_under="over"):
    """
    Evaluate if a PRA prop hits based on the line and average.
    
    Args:
        line: The betting line (e.g., 25.5)
        avg_pra: Average PRA from last 5 games
        over_under: "over" or "under" (default: "over")
    
    Returns:
        dict with 'result', 'confidence', 'edge'
    """
    if avg_pra is None or line is None:
        return {
            'result': 'SKIP',
            'confidence': 'N/A',
            'edge': 0,
            'recommendation': 'Insufficient data'
        }
    
    try:
        line = float(line)
        avg_pra = float(avg_pra)
    except (ValueError, TypeError):
        return {
            'result': 'SKIP',
            'confidence': 'N/A',
            'edge': 0,
            'recommendation': 'Invalid data'
        }
    
    # Calculate the edge (difference between avg and line)
    edge = avg_pra - line
    
    # Determine result based on over/under
    if over_under.lower() == "over":
        result = "HIT" if avg_pra > line else "MISS"
        confidence_value = abs(edge)
    else:  # under
        result = "HIT" if avg_pra < line else "MISS"
        confidence_value = abs(edge)
    
    # Determine confidence level
    if confidence_value >= 5:
        confidence = "HIGH"
    elif confidence_value >= 2:
        confidence = "MEDIUM"
    else:
        confidence = "LOW"
    
    # Build recommendation
    if result == "HIT" and confidence in ["HIGH", "MEDIUM"]:
        recommendation = f"✅ PLAY ({confidence} confidence)"
    elif result == "HIT" and confidence == "LOW":
        recommendation = "⚠️ LEAN (Low confidence)"
    else:
        recommendation = f"❌ AVOID ({result})"
    
    return {
        'result': result,
        'confidence': confidence,
        'edge': round(edge, 1),
        'recommendation': recommendation
    }


def evaluate_all_props(props_with_stats):
    """
    Evaluate multiple props and return analysis
    
    Args:
        props_with_stats: List of prop dicts with 'line', 'avg_pra', 'stat' fields
    
    Returns:
        List of props with evaluation results
    """
    evaluated = []
    
    for prop in props_with_stats:
        # Determine if it's over or under based on stat field
        stat = prop.get('stat', '').lower()
        over_under = "under" if "under" in stat else "over"
        
        # Parse line
        line = prop.get('line')
        avg_pra = prop.get('avg_pra')
        
        # Evaluate
        evaluation = evaluate_pra_prop(line, avg_pra, over_under)
        
        # Add evaluation to prop
        prop['evaluation'] = evaluation
        evaluated.append(prop)
    
    return evaluated


def get_plays_summary(evaluated_props):
    """
    Get summary of plays (how many hits, misses, etc.)
    
    Returns:
        dict with counts
    """
    summary = {
        'total': len(evaluated_props),
        'plays': 0,
        'leans': 0,
        'avoid': 0,
        'skip': 0
    }
    
    for prop in evaluated_props:
        rec = prop.get('evaluation', {}).get('recommendation', '')
        if '✅ PLAY' in rec:
            summary['plays'] += 1
        elif '⚠️ LEAN' in rec:
            summary['leans'] += 1
        elif '❌ AVOID' in rec:
            summary['avoid'] += 1
        else:
            summary['skip'] += 1
    
    return summary
