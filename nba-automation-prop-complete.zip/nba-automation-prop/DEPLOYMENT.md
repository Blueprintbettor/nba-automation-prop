# Deployment Guide - Google Cloud Run

## Prerequisites

1. **Google Cloud Account** with billing enabled
2. **Google Cloud SDK (gcloud)** installed: https://cloud.google.com/sdk/docs/install
3. **Docker** installed (optional, for local testing)

## Step 1: Set Up Google Cloud Project

```bash
# Login to Google Cloud
gcloud auth login

# Create a new project (or use existing)
gcloud projects create nba-props-analyzer --name="NBA Props Analyzer"

# Set the project
gcloud config set project nba-props-analyzer

# Enable required APIs
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com
gcloud services enable sheets.googleapis.com
```

## Step 2: Create Service Account for Sheets Access

```bash
# Create service account
gcloud iam service-accounts create nba-props-sa \
    --display-name="NBA Props Service Account"

# Get your project ID
PROJECT_ID=$(gcloud config get-value project)

# Grant Sheets API access
gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:nba-props-sa@$PROJECT_ID.iam.gserviceaccount.com" \
    --role="roles/editor"
```

**IMPORTANT**: Share your Google Sheet with the service account email:
- Email: `nba-props-sa@[PROJECT_ID].iam.gserviceaccount.com`
- Permission: **Viewer** access

## Step 3: Deploy to Cloud Run

```bash
# Set region (choose closest to you)
export REGION=us-central1

# Deploy the service
gcloud run deploy nba-props-analyzer \
    --source . \
    --platform managed \
    --region $REGION \
    --allow-unauthenticated \
    --set-env-vars SHEET_ID="1BEWBO-JZWQIjAtIgL69sK47ZXnLPwkE4VYI_uVVq8bg" \
    --set-env-vars SHEET_RANGE="INPUT_LINES!A2:E50" \
    --set-env-vars DISCORD_WEBHOOK_URL="https://discord.com/api/webhooks/1456668428784894184/QQeq0pHtiZWZqHpiQ2pyRxIf3CyZ64sqAohB0RW_yu_9oiWg1fEntfrlz88fV13_JXkp" \
    --service-account nba-props-sa@$PROJECT_ID.iam.gserviceaccount.com
```

This will:
- Build your Docker image using Cloud Build
- Deploy to Cloud Run
- Output a service URL

## Step 4: Test the Deployment

After deployment, you'll get a URL like:
`https://nba-props-analyzer-xxxxx-uc.a.run.app`

Test the endpoints:

```bash
# Health check
curl https://YOUR-SERVICE-URL.run.app/

# Run the analyzer
curl -X POST https://YOUR-SERVICE-URL.run.app/run

# Or use GET
curl https://YOUR-SERVICE-URL.run.app/run
```

## Step 5: Set Up Cloud Scheduler (Optional - for daily automation)

```bash
# Enable Cloud Scheduler API
gcloud services enable cloudscheduler.googleapis.com

# Create a job that runs daily at 9 AM
gcloud scheduler jobs create http nba-props-daily \
    --location $REGION \
    --schedule "0 9 * * *" \
    --uri "https://YOUR-SERVICE-URL.run.app/run" \
    --http-method POST \
    --time-zone "America/Chicago"
```

## Environment Variables

You can update environment variables without redeploying:

```bash
gcloud run services update nba-props-analyzer \
    --region $REGION \
    --set-env-vars SHEET_ID="your-new-sheet-id"
```

Available environment variables:
- `SHEET_ID` - Google Sheet ID
- `SHEET_RANGE` - Range to read (default: INPUT_LINES!A2:E50)
- `DISCORD_WEBHOOK_URL` - Discord webhook URL
- `USE_SIMPLE_FORMAT` - Set to "true" for simple Discord format

## Local Testing (Optional)

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
export SHEET_ID="1BEWBO-JZWQIjAtIgL69sK47ZXnLPwkE4VYI_uVVq8bg"
export SHEET_RANGE="INPUT_LINES!A2:E50"
export DISCORD_WEBHOOK_URL="your-webhook-url"

# For local testing with service account
export GOOGLE_APPLICATION_CREDENTIALS="path/to/service-account-key.json"

# Run locally
python main.py

# Test in another terminal
curl -X POST http://localhost:8080/run
```

## Monitoring and Logs

```bash
# View logs
gcloud run services logs read nba-props-analyzer --region $REGION --limit 50

# Stream logs in real-time
gcloud run services logs tail nba-props-analyzer --region $REGION
```

## Troubleshooting

### Issue: "Permission denied" when accessing Google Sheets

**Solution**: Make sure you've shared the Google Sheet with the service account email:
`nba-props-sa@[PROJECT_ID].iam.gserviceaccount.com`

### Issue: "Discord webhook failed"

**Solution**: 
1. Verify webhook URL is correct
2. Check Discord channel permissions
3. Test webhook manually: `curl -X POST [WEBHOOK_URL] -H "Content-Type: application/json" -d '{"content":"Test"}'`

### Issue: "BallDontLie API rate limit"

**Solution**: 
- Free tier is limited
- Consider adding delays between requests
- Upgrade to paid tier if needed

## Cost Estimation

Cloud Run pricing (as of 2024):
- First 2 million requests/month: FREE
- Container instances: ~$0.00002400 per second
- For occasional use: **Expect ~$0-5/month**

## Updating the Service

When you make code changes:

```bash
# Redeploy with new code
gcloud run deploy nba-props-analyzer \
    --source . \
    --region $REGION
```

That's it! Your NBA Props Analyzer is now running on Google Cloud Run! 🏀
